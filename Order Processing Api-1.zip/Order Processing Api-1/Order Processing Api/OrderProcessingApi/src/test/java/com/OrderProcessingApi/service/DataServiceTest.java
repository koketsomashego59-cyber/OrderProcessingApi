package com.OrderProcessingApi.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.OrderProcessingApi.model.Data;
import com.OrderProcessingApi.repository.Interface;

/** Unit tests: the repository is mocked, so no MySQL database is needed. */
@ExtendWith(MockitoExtension.class)
class DataServiceTest {

    @Mock
    private Interface repository;

    @InjectMocks
    private DataService service;

    @Test
    void create_savesRecord() {
        when(repository.save(any(Data.class))).thenAnswer(inv -> inv.getArgument(0));

        Data saved = service.create("John", "Laptop", 2);

        assertNotNull(saved);
        assertEquals("John", saved.getCustomerName());
        assertEquals("Laptop", saved.getProduct());
        assertEquals(2, saved.getQuantity());
    }

    @Test
    void create_rejectsNullQuantity() {
        assertThrows(IllegalArgumentException.class, () -> service.create("John", "Laptop", null));
        verify(repository, never()).save(any(Data.class));
    }

    @Test
    void create_rejectsBlankCustomerName() {
        assertThrows(IllegalArgumentException.class, () -> service.create("", "Laptop", 1));
        verify(repository, never()).save(any(Data.class));
    }

    @Test
    void update_changesFields() {
        Data data = new Data("John", "Laptop", 2);
        when(repository.findById(1)).thenReturn(Optional.of(data));
        when(repository.save(any(Data.class))).thenAnswer(inv -> inv.getArgument(0));

        Data result = service.update(1, "Jane", "Tablet", 5);

        assertEquals("Jane", result.getCustomerName());
        assertEquals("Tablet", result.getProduct());
        assertEquals(5, result.getQuantity());
    }

    @Test
    void findById_throwsWhenRecordDoesNotExist() {
        when(repository.findById(99)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> service.findById(99));
    }
}
