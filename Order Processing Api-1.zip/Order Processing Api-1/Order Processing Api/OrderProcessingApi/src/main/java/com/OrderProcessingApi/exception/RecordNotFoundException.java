/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.exception;
/**
 *
 * @author Future CEO
 */
/** Thrown when a record with the requested ID does not exist. */
public class RecordNotFoundException extends IllegalArgumentException {

    public RecordNotFoundException(int id) {
        super("No record found with ID " + id);
    }
}
