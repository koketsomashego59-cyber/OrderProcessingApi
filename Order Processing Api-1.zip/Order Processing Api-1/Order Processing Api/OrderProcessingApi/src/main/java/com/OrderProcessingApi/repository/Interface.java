/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.OrderProcessingApi.model.Data;

/**
 * Repository: Spring Data JPA generates the implementation at runtime.
 * Provides save(), findAll(), findById(), existsById(), deleteById() ...
 */
@Repository
public interface Interface extends JpaRepository<Data, Integer> {
}
