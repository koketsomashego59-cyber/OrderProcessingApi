/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.exception;
/**
 *
 * @author Future CEO
 */
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/** Global exception handling: turns exceptions into meaningful JSON errors. */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** ID does not exist -> 404 (more specific than IllegalArgumentException, so it wins). */
    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(RecordNotFoundException ex) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    /** Validation problems (blank name, bad phone number ...) -> 400. */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    /** Malformed JSON body -> 400. */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleUnreadable(HttpMessageNotReadableException ex) {
        return build(HttpStatus.BAD_REQUEST, "Malformed or invalid JSON request body");
    }

    /** Non-numeric ID in the URL, e.g. /Customers/abc -> 400. */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {
        return build(HttpStatus.BAD_REQUEST, "Invalid value '" + ex.getValue() + "' for '" + ex.getName() + "'");
    }

    /**
     * Everything else. Spring's own web errors (405 wrong HTTP method, 404 unknown URL,
     * 415 unsupported content type ...) keep their correct status code; anything truly
     * unexpected becomes 500.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneral(Exception ex) {
        if (ex instanceof org.springframework.web.ErrorResponse) {
            org.springframework.web.ErrorResponse springError = (org.springframework.web.ErrorResponse) ex;
            int code = springError.getStatusCode().value();
            HttpStatus resolved = HttpStatus.resolve(code);
            String reason = resolved != null ? resolved.getReasonPhrase() : "Error";
            String detail = springError.getBody().getDetail();
            return ResponseEntity.status(code)
                    .headers(springError.getHeaders())
                    .body(ErrorResponse.of(code, reason, detail != null ? detail : ex.getMessage()));
        }
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred");
    }

    private ResponseEntity<ErrorResponse> build(HttpStatus status, String message) {
        return ResponseEntity.status(status)
                .body(ErrorResponse.of(status.value(), status.getReasonPhrase(), message));
    }
}
