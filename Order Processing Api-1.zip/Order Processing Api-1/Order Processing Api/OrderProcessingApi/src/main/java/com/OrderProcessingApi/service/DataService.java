/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.service;
/**
 *
 * @author Future CEO
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OrderProcessingApi.exception.RecordNotFoundException;
import com.OrderProcessingApi.model.Data;
import com.OrderProcessingApi.repository.Interface;

/**
 * Service: business rules (validation).
 * The repository is injected by Spring (dependency injection).
 */
@Service
public class DataService {

    private final Interface repository;

    @Autowired
    public DataService(Interface repository) {
        this.repository = repository;
    }

    // ---------- CREATE ----------
    public Data create(String customerName, String product, Integer quantity) {
        validate(customerName, product, quantity);
        Data data = new Data(customerName.trim(), product.trim(), quantity);
        Data saved = repository.save(data);
        saveOrderToTxt(saved);
        return saved;
    }

    // ---------- READ ----------
    public List<Data> findAll() {
        return repository.findAll();
    }

    public Data findById(int id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecordNotFoundException(id));
    }

    // ---------- UPDATE ----------
    public Data update(int id, String customerName, String product, Integer quantity) {
        validate(customerName, product, quantity);
        Data existing = findById(id);
        existing.setCustomerName(customerName.trim());
        existing.setProduct(product.trim());
        existing.setQuantity(quantity);
        return repository.save(existing);
    }

    // ---------- DELETE ----------
    public void delete(int id) {
        if (!repository.existsById(id)) {
            throw new RecordNotFoundException(id);
        }
        repository.deleteById(id);
    }

    private void validate(String customerName, String product, Integer quantity) {
        if (customerName == null || customerName.isBlank() || customerName.trim().length() > 100) {
            throw new IllegalArgumentException("Customer name is required (maximum 100 characters)");
        }
        if (product == null || product.isBlank() || product.trim().length() > 100) {
            throw new IllegalArgumentException("Product is required (maximum 100 characters)");
        }
        if (quantity == null || quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1");
        }
    }

    // ---------- TXT FILE EXPORT ----------
    public String saveOrderToTxt(Data data) {
        String filename = (data.getOrderId() != null) ? "order_" + data.getOrderId() + ".txt" : "order.txt";
        try {
            // Write individual order file
            String content = "==================================================" + System.lineSeparator()
                    + "                 ORDER DETAILS" + System.lineSeparator()
                    + "==================================================" + System.lineSeparator()
                    + "Order ID:       " + (data.getOrderId() != null ? data.getOrderId() : "N/A") + System.lineSeparator()
                    + "Customer Name:  " + data.getCustomerName() + System.lineSeparator()
                    + "Product:        " + data.getProduct() + System.lineSeparator()
                    + "Quantity:       " + data.getQuantity() + System.lineSeparator()
                    + "==================================================" + System.lineSeparator();
            Files.writeString(Path.of(filename), content);

            // Also append to master orders.txt
            String logEntry = String.format("ID: %-5s | Customer: %-20s | Product: %-15s | Quantity: %-5d%n",
                    (data.getOrderId() != null ? String.valueOf(data.getOrderId()) : "N/A"),
                    data.getCustomerName(),
                    data.getProduct(),
                    data.getQuantity());
            Files.writeString(
                    Path.of("orders.txt"),
                    logEntry,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );
        } catch (IOException e) {
            System.err.println("Error saving order to text file: " + e.getMessage());
        }
        return filename;
    }

    public String saveAllOrdersToTxt(List<Data> list) {
        String filename = "orders.txt";
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("======================================================================").append(System.lineSeparator());
            sb.append("                         RETAIL STORE ORDERS                          ").append(System.lineSeparator());
            sb.append("======================================================================").append(System.lineSeparator());
            sb.append(String.format("%-5s %-25s %-20s %-10s%n", "ID", "Customer Name", "Product", "Quantity"));
            sb.append("-".repeat(70)).append(System.lineSeparator());
            for (Data d : list) {
                sb.append(String.format("%-5s %-25s %-20s %-10d%n",
                        (d.getOrderId() != null ? String.valueOf(d.getOrderId()) : "N/A"),
                        d.getCustomerName(),
                        d.getProduct(),
                        d.getQuantity()));
            }
            sb.append("======================================================================").append(System.lineSeparator());
            Files.writeString(Path.of(filename), sb.toString());
        } catch (IOException e) {
            System.err.println("Error saving all orders to text file: " + e.getMessage());
        }
        return filename;
    }
}
