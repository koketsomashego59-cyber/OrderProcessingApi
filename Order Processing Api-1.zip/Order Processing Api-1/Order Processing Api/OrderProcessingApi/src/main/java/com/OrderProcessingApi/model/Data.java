/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.model;
/**
 *
 * @author Future CEO
 */
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Model: maps to the "Customers" table in RetailDatabase.
 */
@Entity
@Table(name = "Customers")
public class Data {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // MySQL AUTO_INCREMENT
    @Column(name = "OrderId")
    private Integer orderId;

    @Column(name = "customerName", length = 100)
    private String customerName;

    @Column(name = "product", length = 100)
    private String product;

    @Column(name = "quantity")
    private Integer quantity;

    // Required by JPA
    public Data() {
    }

    public Data(String customerName, String product, Integer quantity) {
        this.customerName = customerName;
        this.product = product;
        this.quantity = quantity;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

}
