/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.view;
/**
 *
 * @author Future CEO
 */
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.OrderProcessingApi.model.Data;
import com.OrderProcessingApi.service.DataService;


@Component
@ConditionalOnProperty(name = "app.console.enabled", havingValue = "true", matchIfMissing = true)
public class CRUD implements CommandLineRunner {

    private final DataService service;
    private Scanner input;

    @Autowired
    public CRUD(DataService service) {
        this.service = service;
    }

    @Override
    public void run(String... args) {
        input = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            String choice = readLine("Choose an option: ");
            if (choice == null) {
                break; // no more input
            }
            try {
                switch (choice) {
                    case "1" -> createRecord();
                    case "2" -> viewAll();
                    case "3" -> viewOne();
                    case "4" -> updateRecord();
                    case "5" -> deleteRecord();
                    case "6" -> saveOrderToTxt();
                    case "0" -> {
                        System.out.println("Menu closed. The REST API is still running on http://localhost:8080 - stop the app in NetBeans to quit.");
                        running = false;
                    }
                    default -> System.out.println("Invalid option. Please choose 0-6.");
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
    }

    // ---------------- MENU ----------------
    private void printMenu() {
        System.out.println();
        System.out.println("--- Retail Store ---");
        System.out.println("1. Create an order");
        System.out.println("2. View all orders.");
        System.out.println("3. Find an order.");
        System.out.println("4. Update an order.");
        System.out.println("5. Delete and order.");
        System.out.println("6. Save order into txt.");
        System.out.println("0. Exit");
        System.out.println("---------------------");
    }

    // ---------------- CREATE ----------------
    private void createRecord() {
        String customerName = readLine("Customer name: ");
        if (customerName == null) {
            return;
        }
        String product = selectProduct();
        if (product == null) {
            return;
        }
        Integer quantity = readQuantity("Quantity: ");
        if (quantity == null) {
            return;
        }
        Data saved = service.create(customerName, product, quantity);
        System.out.println("Record created. ID = " + saved.getOrderId());
        System.out.println("Data automatically saved to txt file (orders.txt and order_" + (saved.getOrderId() != null ? saved.getOrderId() : "N/A") + ".txt).");
    }

    // ---------------- READ ----------------
    private void viewAll() {
        List<Data> all = service.findAll();
        if (all.isEmpty()) {
            System.out.println("No records found.");
            return;
        }
        printHeader();
        for (Data d : all) {
            printRow(d);
        }
    }

    private void viewOne() {
        Integer id = readId();
        if (id == null) {
            return;
        }
        printHeader();
        printRow(service.findById(id));
    }

    // ---------------- UPDATE ----------------
    private void updateRecord() {
        Integer id = readId();
        if (id == null) {
            return;
        }
        Data current = service.findById(id);
        System.out.println("Press Enter to keep the current value.");

        String customerName = readLine("Customer name [" + current.getCustomerName() + "]: ");
        String product = selectProductForUpdate(current.getProduct());
        if (product == null) {
            return;
        }
        String quantityStr = readLine("Quantity [" + current.getQuantity() + "]: ");

        if (customerName == null || customerName.isBlank()) customerName = current.getCustomerName();
        if (product == null || product.isBlank()) product = current.getProduct();
        Integer quantity;
        if (quantityStr == null || quantityStr.isBlank()) {
            quantity = current.getQuantity();
        } else {
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid quantity. Please enter a whole number.");
                return;
            }
        }

        service.update(id, customerName, product, quantity);
        System.out.println("Record updated.");
    }

    // ---------------- DELETE ----------------
    private void deleteRecord() {
        Integer id = readId();
        if (id == null) {
            return;
        }
        String confirm = readLine("Delete record " + id + "? (y/n): ");
        if (confirm != null && confirm.equalsIgnoreCase("y")) {
            service.delete(id);
            System.out.println("Record deleted.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    // ---------------- SAVE TO TXT ----------------
    private void saveOrderToTxt() {
        Integer id = readId();
        if (id == null) {
            return;
        }
        Data order = service.findById(id);
        String filename = service.saveOrderToTxt(order);
        System.out.println("Order " + id + " successfully saved to " + filename + " and orders.txt");
    }

    // ---------------- HELPERS ----------------
    private void printHeader() {
        System.out.printf("%-5s %-20s %-20s %-10s%n", "ID", "Customer Name", "Product", "Quantity");
        System.out.println("-".repeat(58));
    }

    private void printRow(Data d) {
        System.out.printf("%-5d %-20s %-20s %-10d%n",
                d.getOrderId(), d.getCustomerName(), d.getProduct(), d.getQuantity());
    }

    private String readLine(String prompt) {
        System.out.print(prompt);
        if (!input.hasNextLine()) {
            return null;
        }
        return input.nextLine().trim();
    }

    private Integer readId() {
        String text = readLine("Enter ID: ");
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException | NullPointerException ex) {
            System.out.println("Invalid ID. Please enter a whole number.");
            return null;
        }
    }

    private Integer readQuantity(String prompt) {
        String text = readLine(prompt);
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException | NullPointerException ex) {
            System.out.println("Invalid quantity. Please enter a whole number.");
            return null;
        }
    }

    private String selectProduct() {
        System.out.println("Select a product:");
        System.out.println("1. PC");
        System.out.println("2. Laptop");
        System.out.println("3. Phone");
        System.out.println("4. Tablet");
        while (true) {
            String choice = readLine("Choose product (1-4): ");
            if (choice == null) {
                return null;
            }
            switch (choice.trim().toLowerCase()) {
                case "1", "pc" -> { return "PC"; }
                case "2", "laptop" -> { return "Laptop"; }
                case "3", "phone" -> { return "Phone"; }
                case "4", "tablet" -> { return "Tablet"; }
                default -> System.out.println("Invalid option. Please choose between 1 and 4.");
            }
        }
    }

    private String selectProductForUpdate(String currentProduct) {
        System.out.println("Select a product (Press Enter to keep [" + currentProduct + "]):");
        System.out.println("1. PC");
        System.out.println("2. Laptop");
        System.out.println("3. Phone");
        System.out.println("4. Tablet");
        while (true) {
            String choice = readLine("Choose product (1-4) [" + currentProduct + "]: ");
            if (choice == null) {
                return null;
            }
            if (choice.isBlank()) {
                return currentProduct;
            }
            switch (choice.trim().toLowerCase()) {
                case "1", "pc" -> { return "PC"; }
                case "2", "laptop" -> { return "Laptop"; }
                case "3", "phone" -> { return "Phone"; }
                case "4", "tablet" -> { return "Tablet"; }
                default -> System.out.println("Invalid option. Please choose between 1 and 4 (or press Enter to keep current).");
            }
        }
    }
}
