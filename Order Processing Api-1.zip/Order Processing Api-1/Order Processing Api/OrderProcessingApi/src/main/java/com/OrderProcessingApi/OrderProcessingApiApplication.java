/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi;

/**
 *
 * @author Future CEO
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderProcessingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderProcessingApiApplication.class, args);
	}

}
