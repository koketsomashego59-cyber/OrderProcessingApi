/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.exception;
/**
 *
 * @author Future CEO
 */
import java.time.Instant;

/** JSON body returned to the client whenever an error occurs. */
public record ErrorResponse(String timestamp, int status, String error, String message) {

    public static ErrorResponse of(int status, String error, String message) {
        return new ErrorResponse(Instant.now().toString(), status, error, message);
    }
}
