/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.OrderProcessingApi.controller;
/**
 *
 * @author Future CEO
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.OrderProcessingApi.model.Data;
import com.OrderProcessingApi.service.DataService;

/**
 * Controller: REST endpoints for Postman.
 */
@RestController
@RequestMapping({"/Customers", "/customers"})
public class DataController {

    private final DataService service;

    @Autowired
    public DataController(DataService service) {
        this.service = service;
    }

    /** GET /Customers : all records */
    @GetMapping
    public List<Data> getAll() {
        return service.findAll();
    }

    /** GET /Customers/{id} : one record */
    @GetMapping("/{id}")
    public Data getById(@PathVariable int id) {
        return service.findById(id);
    }

    /** POST /Customers : create a new order */
    @PostMapping
    public ResponseEntity<Data> create(@RequestBody Data data) {
        Data saved = service.create(data.getCustomerName(), data.getProduct(), data.getQuantity());
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    /** PUT /Customers/{id} : update customer name, product, quantity */
    @PutMapping("/{id}")
    public Data update(@PathVariable int id, @RequestBody Data data) {
        return service.update(id, data.getCustomerName(), data.getProduct(), data.getQuantity());
    }

    /** DELETE /Customers/{id} */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
